Kenny Shao 

Chess Game Simulation

I implemented the isLegal moves for every piece and created the command methods
for capturing, moving, printing the board, undo a move, and quitting the game.
I didn't implement castling, promotion or en Passant.

